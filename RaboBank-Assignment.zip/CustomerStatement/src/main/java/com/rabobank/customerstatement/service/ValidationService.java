package com.rabobank.customerstatement.service;

import java.util.List;

import com.rabobank.customerstatement.model.Record;

public interface ValidationService {

	public List<Record> getDuplicateRecords(List<Record> records);

	public List<Record> getEndBalanceErrorRecords(List<Record> records);

}
