package com.rabobank.customerstatement.service;

import java.io.File;
import java.util.List;

import com.rabobank.customerstatement.model.Record;

public interface ExtractorService {

	public List<Record> extractStatementFromCSV(File file) throws Exception;

	public List<Record> extractStatementFromXML(File file) throws Exception;

}