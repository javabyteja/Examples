package com.rabobank.customerstatement.controller;


import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.rabobank.customerstatement.model.AppResponse;
import com.rabobank.customerstatement.model.Record;
import com.rabobank.customerstatement.service.ExtractorService;
import com.rabobank.customerstatement.service.ValidationService;
import com.rabobank.customerstatement.util.Constants;


@RestController
@RequestMapping("/rabobank")
public class CustomerStatementProcessController {
	@Autowired
	private ValidationService validationService;

	@Autowired
	private ExtractorService extractorService;
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public @ResponseBody AppResponse test() throws Exception {
		AppResponse appResponse = new AppResponse();
		return appResponse;
	}

	@RequestMapping(value = "/customerStatment", method = RequestMethod.POST)
	public @ResponseBody AppResponse handleFileUpload(@RequestParam("file") MultipartFile multipart) throws Exception {
		AppResponse appResponse = new AppResponse();
		if (!multipart.isEmpty()) {
			if (multipart.getContentType().equalsIgnoreCase(Constants.FILE_TYPE_CSV)) {
				List<Record> errorRecords = new ArrayList<Record>();
				File csvFile = new File(multipart.getOriginalFilename());
				multipart.transferTo(csvFile);
				List<Record> extractedRecords = extractorService.extractStatementFromCSV(csvFile);
				errorRecords.addAll(validationService.getDuplicateRecords(extractedRecords));
				errorRecords.addAll(validationService.getEndBalanceErrorRecords(extractedRecords));
				if (!errorRecords.isEmpty()) {
					appResponse.setResponseCode(Constants.HTTP_CODE_SUCCESS);
					appResponse.setResponseMessage(Constants.VALIDATION_ERROR);
					appResponse.setRecords(errorRecords);
				} else {
					appResponse.setResponseCode(Constants.HTTP_CODE_SUCCESS);
					appResponse.setResponseMessage(Constants.VALIDATION_ERROR);
				}
			} else if (multipart.getContentType().equalsIgnoreCase(Constants.FILE_TYPE_XML)) {
				List<Record> errorRecords = new ArrayList<Record>();
				File xmlFile = new File(multipart.getOriginalFilename());
				multipart.transferTo(xmlFile);
				List<Record> extractedRecords = extractorService.extractStatementFromXML(xmlFile);
				errorRecords.addAll(validationService.getDuplicateRecords(extractedRecords));
				errorRecords.addAll(validationService.getEndBalanceErrorRecords(extractedRecords));
				if (!errorRecords.isEmpty()) {
					appResponse.setResponseCode(Constants.HTTP_CODE_SUCCESS);
					appResponse.setResponseMessage(Constants.VALIDATION_ERROR);
					appResponse.setRecords(errorRecords);
				} else {
					appResponse.setResponseCode(Constants.HTTP_CODE_SUCCESS);
					appResponse.setResponseMessage(Constants.VALIDATION_ERROR);
				}
			} else {
				appResponse.setResponseCode(Constants.HTTP_CODE_INVALID_INPUT);
				appResponse.setResponseMessage(Constants.UNSUPORTED_FILE_FORMAT);
			}
		} else {
			appResponse.setResponseCode(Constants.HTTP_CODE_INVALID_INPUT);
			appResponse.setResponseMessage(Constants.INVALID_INPUT);
		}
		return appResponse;
	}

	@ExceptionHandler(Exception.class)
	public @ResponseBody AppResponse handleException(HttpServletRequest request, Exception ex) {
		AppResponse appResponse = new AppResponse();
		appResponse.setResponseCode(Constants.HTTP_CODE_ERROR);
		appResponse.setResponseMessage(Constants.UNEXPECTED_SERVER_ERROR);
		return appResponse;
	}
}
