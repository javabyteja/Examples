package com.rabobank.customerstatement.service;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import com.opencsv.CSVReader;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.HeaderColumnNameTranslateMappingStrategy;
import com.rabobank.customerstatement.model.Record;
import com.rabobank.customerstatement.model.Records;

public class ExtractorServiceImpl {
	/*
	 * Return list of records from csv file
	 */
	public List<Record> extractStatementFromCSV(File file) throws Exception{
		HeaderColumnNameTranslateMappingStrategy<Record> beanStrategy = new HeaderColumnNameTranslateMappingStrategy<Record>();
		beanStrategy.setType(Record.class);
		Map<String,String>  columnMapping= new HashMap<String,String>();
		columnMapping.put("Reference", "txnRef");
		columnMapping.put("Account Number", "accountNumber");
		columnMapping.put("Start Balance", "startBalance");
		columnMapping.put("Mutation", "mutation");
		columnMapping.put("Description", "description");
		columnMapping.put("End Balance", "endBalance");

		beanStrategy.setColumnMapping(columnMapping);

		CsvToBean<Record> csvToBean = new CsvToBean<Record>();
		CSVReader reader = new CSVReader(new FileReader(file));
		@SuppressWarnings("deprecation")
		List<Record> records = csvToBean.parse(beanStrategy, reader);
		return records;

	}
	/*
	 * Return List of records from XML
	 */
	public List<Record> extractStatementFromXML(File file) throws Exception{
		JAXBContext jaxbContent =  JAXBContext.newInstance(Records.class);
		Unmarshaller jaxbUnmarshaller = jaxbContent.createUnmarshaller();
		Records rootRecord = (Records)jaxbUnmarshaller.unmarshal(file);
		return  rootRecord.getRecord();
	}
}
