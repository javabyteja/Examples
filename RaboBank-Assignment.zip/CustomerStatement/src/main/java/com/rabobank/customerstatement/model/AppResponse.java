package com.rabobank.customerstatement.model;

import java.util.List;

public class AppResponse {
	private String responseMessage;
	private int responseCode;
	private List<Record> records;
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public int getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}
	public List<Record> getRecords() {
		return records;
	}
	public void setRecords(List<Record> records) {
		this.records = records;
	}
	@Override
	public String toString() {
		return "Response [responseMessage=" + responseMessage + ", responseCode=" + responseCode + ", records=" + records
				+ "]";
	}

}
