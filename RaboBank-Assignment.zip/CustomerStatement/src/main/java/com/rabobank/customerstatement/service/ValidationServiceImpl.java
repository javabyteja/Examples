package com.rabobank.customerstatement.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rabobank.customerstatement.model.Record;

public class ValidationServiceImpl implements ValidationService {
	/*
	 * Get the list of duplicate records.
	 */
	public List<Record> getDuplicateRecords(List<Record> records){
		Map<Integer,Record> uniqueRecords = new HashMap<Integer, Record>();
		List<Record> duplicateRecords = new ArrayList<Record>();
		for(Record record : records) {
			if(uniqueRecords.containsKey(record.getTxnRef())) {
				duplicateRecords.add(record);
			}else {
				uniqueRecords.put(record.getTxnRef(), record);
			}
		}
		List<Record> finalDuplicateRecords = new ArrayList<Record>();
		finalDuplicateRecords.addAll(duplicateRecords);
		for(Record record : duplicateRecords) {
			if(null!= uniqueRecords.get(record.getTxnRef())) {
				finalDuplicateRecords.add(uniqueRecords.get(record.getTxnRef()));
				uniqueRecords.remove(record.getTxnRef());
			}
		}
		return finalDuplicateRecords;

	} 
	/*
	 * Get the error End Balance records.
	 */
	public List<Record> getEndBalanceErrorRecords(List<Record> records){
		List<Record> endBalanceErrorRecords = new ArrayList<Record>();
		for (Record record : endBalanceErrorRecords) {
			if(Math.round((record.getStartBalance() - record.getMutation()) - Math.round(record.getEndBalance())) != 0) {
				endBalanceErrorRecords.add(record);
			}

		}
		return  endBalanceErrorRecords;
	}
}

