# Rabobank Customer Statement Processor
Rabobank receives monthly deliveries of customer statement records. This information is delivered in two formats, CSV and XML. These records need to be validated.

## Input
The format of the file is a simplified format of the MT940 format. The format is as follows:

Field  |Description
----|----
Transaction reference  | A numeric value
Account number   | An IBAN 
Account | IBAN 
Start Balance | The starting balance in Euros 
Mutation | Either and addition (+) or a deducation (-) 
Description | Free text 
End Balance | The end balance in Euros 

## Expected output
There are two validations:
* all transaction references should be unique
* the end balance needs to be validated

At the end of the processing, a report needs to be created which will display both the transaction reference and description of each of the failed records.

# Steps to run the application:
1.	Download the zip file (CustomerStatement) and extract.
Import the project from available location.

2.Update the project.

3.Run the application as spring boot Application(click ctrl+F11).
4.youn will find the response in postman through service url

http://localhost:8443/CustomerStatement/rabobank/customerStatment
5.	Upload input csv/xml file in the service using postman client.
6.	The input file will be validated based on two conduction mentioned in the problem statment.(validation condition mentioned in expected output section)
      *	Duplicate Transaction key check, 
      *	End balance calculation check. (endbalance = startbalance – mutation)
7.  Finally invalid records will be getting as webservice response with status code. 

