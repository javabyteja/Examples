/*package com.rabobank.cusomerstatemet.test;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.rabobank.customerstatement.model.Record;
import com.rabobank.customerstatement.service.ExtractorServiceImpl;
import com.rabobank.customerstatement.service.ValidationService;
import com.rabobank.customerstatement.service.ValidationServiceImpl;
import com.rabobank.customerstatement.util.TestCaseUtil;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CustomerStatementApplicationTests {

 * Duplicate check in positive scenario


 *//**
 * EndBalance validation in given Rabobank Customer
 * Statement in positive scenario
 *//*
	@Test
	public void getEndBalanceErrorRecordsTestCaseWithWrongValue() {
		List<Record> inputList = Arrays.asList(
				new Record(172833, "NL69ABNA0433647324", 66.72, -41.74, "Tickets for Willem Theuß", 24.98),
				new Record(172833, "NL43AEGO0773393871", 16.52, +43.09, "Tickets for Willem Theuß", 59.80));
		ValidationServiceImpl validatorServiceImpl = new ValidationServiceImpl();
		List<Record> endBalanceErrorRecords = validatorServiceImpl.getEndBalanceErrorRecords(inputList);
		assertEquals(inputList.size(), endBalanceErrorRecords.size());

	}

  *//**
  * 
  * EndBalance validation in given Rabobank Customer
  * Statement in negative scenario
  *//*
	@Test
	public void getEndBalanceErrorRecordsTestCaseWithCorrectValue() {
		List<Record> inputList = Arrays.asList(
				new Record(172833, "NL69ABNA0433647324", 66.72, -41.74, "Tickets for Willem Theuß", 108.46),
				new Record(172833, "NL43AEGO0773393871", 16.52, +43.09, "Tickets for Willem Theuß", -26.57));
		ValidationServiceImpl validationrServiceImpl = new ValidationServiceImpl();
		List<Record> endBalanceErrorRecords = validationrServiceImpl.getEndBalanceErrorRecords(inputList);
		assertEquals(0, endBalanceErrorRecords.size());
	}

   *//**
   *  Processing the input CSV file and extracting
   * values as POJO object for validation process in positive scenario
   *//*
	@Test
	public void extractStatmentFromCSVTestCase() {
		ExtractorServiceImpl extractorServiceImpl = new ExtractorServiceImpl();
		File inputFile = new File("records.csv");
		try {
			int totalLineInInputCSV = TestCaseUtil.getNumberOfLine(inputFile);
			List<Record> extractedRecords = extractorServiceImpl.extractStatementFromCSV(inputFile);
			assertEquals(totalLineInInputCSV-1, extractedRecords.size());
		} catch (IOException e) {
			Assert.fail("File processing error!!" + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void getDuplicateRecordsTestCaseWithDuplilcate() {
		List<Record> inputList = Arrays.asList(
				new Record(172833, "NL69ABNA0433647324", 66.72, -41.74, "Tickets for Willem Theuß", 24.98),
				new Record(172833, "NL43AEGO0773393871", 16.52, +43.09, "Tickets for Willem Theuß", 59.61));
		ValidationServiceImpl validatorServiceImpl = new ValidationServiceImpl();
		List<Record> duplicateRecords = validatorServiceImpl.getDuplicateRecords(inputList);
		assertEquals(inputList.size(), duplicateRecords.size());

	}


    *//**
    * duplicate check in negative scenario
    *//*
	@Test
	public void getDuplicateRecordsTestCaseWithOutDuplilcate() {
		List<Record> inputList = Arrays.asList(
				new Record(172823, "NL69ABNA0433647324", 66.72, -41.74, "Tickets for Willem Theuß", 24.98),
				new Record(172833, "NL43AEGO0773393871", 16.52, +43.09, "Tickets for Willem Theuß", 59.61));
		ValidationService validatorServiceImpl = new ValidationServiceImpl();
		List<Record> duplicateRecords = ValidationService.getDuplicateRecords(inputList);
		assertEquals(0, duplicateRecords.size());

	}

     *//**
     *  Processing the input XML file and extracting
     * values as POJO object for validation process in positive scenario
     *//*
	@SuppressWarnings("deprecation")
	@Test
	public void extractStatmentFromXMLTestCase() {
		ExtractorServiceImpl extractorServiceImpl = new ExtractorServiceImpl();
		File inputFile = new File("records.xml");
		try {
			int totalLineInInputXML = 10; /// let. input XML file has 10 records.
			List<Record> extractedRecords = extractorServiceImpl.extractStatementFromXML(inputFile);
			assertEquals(totalLineInInputXML, extractedRecords.size());
		} catch (Exception e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}

}
      */